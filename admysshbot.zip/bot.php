<?php

// Acesse @rickcloudbr e fique por dentro de todas as novidades 

date_default_timezone_set ('Africa/kampala'); // define timestamp padrão

// Incluindo arquivos nescessários
include __DIR__.'/Telegram.php';

if (!file_exists('dadosBot.ini')){

	echo "Install bot first!";
	exit;

}

$textoMsg=json_decode (file_get_contents('textos.json'));
$iniParse=parse_ini_file('dadosBot.ini');

$ip=$iniParse ['ip'];
$token=$iniParse ['token'];
$limite=$iniParse ['limite'];

define ('TOKEN', $token); // token do bot criado no @botfather

// Instancia das classes
$tlg=new Telegram (TOKEN);
$redis=new Redis ();
$redis->connect ('localhost', 6379); //redis usando porta padrão

// BLOCO USADO EM LONG POLLING

while (true){

$updates=$tlg->getUpdates();

for ($i=0; $i < $tlg->UpdateCount(); $i++){

$tlg->serveUpdate($i);

switch ($tlg->Text ()){

	case '/start':

	$tlg->sendMessage ([
		'chat_id' => $tlg->ChatID (),
		'text' => $textoMsg->start,
		'parse_mode' => 'html',
		'reply_markup' => $tlg->buildInlineKeyBoard ([
			[$tlg->buildInlineKeyboardButton ('⚡️GET A FREE ACC.⚡️', null, '/sshgratis')],
			[$tlg->buildInlineKeyboardButton ('Buy Premium (fast) 💰', null, 'teslassh.t.me')],
			[$tlg->buildInlineKeyboardButton ('Join Channel 🤝', null, 'udpcustom.t.me')]
	])
]);

	break;
	case '/sobre':

	$tlg->sendMessage ([
		'chat_id' => $tlg->ChatID (),
		'text' => 'By Tesla SSH'
	]);

	break;
	case '/total':

	$tlg->sendMessage ([
		'chat_id' => $tlg->ChatID (),
		'text' => 'So far <b>'.$redis->dbSize ().'</b> accounts created in the last 24 hours',
		'parse_mode' => 'html'
	]);

	break;
	case '/sshgratis':

	$tlg->answerCallbackQuery ([
	'callback_query_id' => $tlg->Callback_ID()
	]);

	if ($redis->dbSize () == $limite){

		$textoSSH=$textoMsg->sshgratis->limite;

	} elseif ($redis->exists ($tlg->UserID ())){

		$textoSSH=$textoMsg->sshgratis->nao_criado;

	} else {

		$random_string = substr(str_shuffle('abcdefghijklmnopqrstuvwxyz'), 0, 4);
		$usuario = 'teslassh-' . $random_string;

		exec ('./gerarusuario.sh '.$usuario.' '.$senha.' 1 1');

		$textoSSH=" SSH ACCOUNT CREATED ;)\r\n\r\n<b>Server IP:</b> <code>".$ip."</code>\r\n<b>Username:</b> <code>".$usuario."</code>\r\n<b>Password:</b> <code>".$senha."</code>\r\n\r\n<b>Logins:</b> 1 Device(s)\r\n<b>Valid for:</b> ".date ('d/m', strtotime('+1 day'))."\r\n\r\n🤙 by Tesla SSH";

		$redis->setex ($tlg->UserID (), 3600, 'true'); //set record to be kept for 12h

	}

	$tlg->sendMessage ([
		'chat_id' => $tlg->ChatID (),
		'text' => $textoSSH,
		'parse_mode' => 'html'
	]);

	break;

}

}}
